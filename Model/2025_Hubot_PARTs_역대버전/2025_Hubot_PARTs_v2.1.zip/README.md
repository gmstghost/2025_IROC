통합본 제작 : 안제욱
RPi5 모델링, CM530 모델링, AX-12A 잡선제거 : 이승민
Frame 잡선제거, Battery_case.skp 모델링 : 안제욱

AX-12A, 프레임의 저작권은 로보티즈에게 있습니다.

** Patch Note
* v1.0 - 최초 제작
* v2.0 - Battery_case.skp 추가
* v2.1 (미배포) - README.md 수정